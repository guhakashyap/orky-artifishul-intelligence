# ORKY TRANSFO'MA' WEBSITE

## WAAAGH! WELCOME TO DA ORKY TRANSFO'MA'!

Dis 'ere is a complete website showcasing a Warhammer 40k Ork-themed Transformer implementation. Built with brutal Orky aesthetics and interactive functionality!

## 🚀 LIVE WEBSITE
**https://v5sjzhghcrlv4.ok.kimi.link**

## 📁 WHAT'S INCLUDED

### Core Files
- `index.html` - Main interactive showcase page
- `documentation.html` - Complete technical documentation
- `playground.html` - Interactive code experimentation environment
- `main.js` - Core JavaScript functionality

### Visual Assets
- `hero-main.png` - Epic Ork workshop hero image
- `attention-heads.png` - Attention mechanism visualization
- `transformer-diagram.png` - Architecture diagram

### Documentation
- `design.md` - Visual design guide and style specifications
- `interaction.md` - Interaction design and user experience guide
- `outline.md` - Project structure and implementation details
- `README.md` - This file!

## 🎯 FEATURES

### Interactive Elements
1. **Clickable Transformer Architecture** - Explore each component
2. **Real-time Attention Visualization** - Input sentences and see attention patterns
3. **Ork Vocabulary Builder** - Add custom Orky words
4. **Live Code Editor** - Edit and run Python transformer code
5. **Training Simulator** - Watch animated training progress
6. **Parameter Controls** - Tweak model configuration in real-time

### Visual Effects
- Industrial Ork-themed design with metal textures
- Particle system with smoke and sparks
- Smooth animations and transitions
- Responsive design for all devices
- Scroll reveal effects
- Glowing energy conduits and electrical effects

### Technical Implementation
- **Anime.js** - Smooth animations
- **ECharts.js** - Data visualization and attention heatmaps
- **CodeMirror** - Syntax-highlighted code editor
- **P5.js** - Particle effects and creative coding
- **Tailwind CSS** - Responsive styling

## 🎨 DESIGN PHILOSOPHY

The website embodies the brutal, ramshackle world of WH40k Orks where technology shouldn't work but does through sheer belief. The design features:

- **Color Palette**: Ork Green, Mekboy Blue, Red Wunz, Yellow Teef
- **Typography**: Oranienbaum for headers, Quattrocento Sans for body
- **Textures**: Industrial metal with rust effects
- **Animations**: Jerky, aggressive movements that feel Orky
- **Atmosphere**: Smoke, sparks, and unstable technology effects

## 🚀 GETTING STARTED

1. **Local Development**:
   ```bash
   python -m http.server 8000
   ```
   Then visit `http://localhost:8000`

2. **Open `index.html`** in your browser to start exploring

3. **Navigate** between pages using the top navigation

4. **Experiment** with the interactive elements:
   - Click on transformer components to learn about them
   - Input Orky sentences to see attention patterns
   - Add custom words to the vocabulary
   - Edit code in the playground
   - Adjust parameters and watch the model stats update

## 🎮 INTERACTION GUIDE

### Main Page (`index.html`)
- **Hero Section**: Animated title with typewriter effect
- **Transformer Diagram**: Click components to learn more
- **Attention Visualizer**: Input sentences and see heatmaps
- **Vocabulary Builder**: Add and manage Orky words
- **Code Showcase**: View and copy the transformer code

### Documentation (`documentation.html`)
- **Technical Manual**: Complete component breakdown
- **Mathematics**: Behind-the-scenes equations
- **API Reference**: Function signatures and parameters
- **Usage Examples**: How to implement and use

### Playground (`playground.html`)
- **Parameter Controls**: Adjust model configuration
- **Code Editor**: Edit and run Python code
- **Attention Visualization**: Interactive heatmaps
- **Training Simulator**: Watch animated training progress

## 🔧 TECHNICAL DETAILS

The Orky Transformer implements standard transformer architecture with Orky flair:

- **Multi-Head Attention** - Multiple Ork heads working together
- **Feed-Forward Networks** - Ork brain processing centers  
- **Layer Normalization** - Keeping the Orks in line
- **Positional Encoding** - Telling Orks where words are
- **Orky Vocabulary** - Built-in support for Orky language

## 🎨 CUSTOMIZATION

Want to make it even more Orky? You can:

1. **Add More Orky Words** - Modify the vocabulary in `main.js`
2. **Change Colors** - Update the CSS variables in the style sections
3. **Add More Particles** - Enhance the P5.js particle system
4. **Extend Functionality** - Add new interactive components

## 📱 RESPONSIVE DESIGN

The website works great on:
- Desktop computers
- Tablets
- Mobile phones
- Different screen sizes and orientations

## 🎉 HAVE FUN!

Remember: RED WUNZ GO FASTA! BLUE IS FOR LUCK! YELLOW MAKES BIGGER BOOMS!

WAAAGH! 🚀⚡💥

---

*Built with Orky love and lots of WAAAGH! energy*